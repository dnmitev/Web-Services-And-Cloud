﻿namespace App.Services.IntegrationTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // TODO: Write integrations tests, if needed
            // Not enough time - sorry :)
        }
    }
}