There may be some problems with the Ninject, please be that kind and in case of problems comment the Ninject use.

For the WCF check the help page when loaded or see this http://localhost:16693/UserInfo.svc/help
Note the port:16693 may be different on your pc. so please check it